B073021024 錢承
B075040041 鄭煥榮

1.Packages:
	Used tkinter, PIL, numpy, matplotlib.pyplot and math packages

	Installation :         
		sudo apt-get install python3
		sudo apt-get install python3-numpy
		sudo apt-get install python3-pip
		pip3 install pygame

2.Environment:
	Distributor ID: 	Ubuntu
	Description:    	Ubuntu 20.04.1 LTS
	Release:        	20.04
	Codename:       	focal

3.Python version:
	Python 3.8.5

4.Graphics display resolution:
	1920 x 1080
